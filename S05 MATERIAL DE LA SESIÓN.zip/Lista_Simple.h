// BIBLIOTECA Lista Simple. 
// FICHERO CABECERA
// DEFINICIONES DE DATOS Y PROTOTIPOS DE RUTINAS
// ESTRUCTURA DE DATOS
// Autor       : Dr. Eladio Dapena Gonzalez
// Uso         : Académico
// Fecha       : 02/01/2026


// DEFINIR NUEVOS TIPOS DE DATOS

// ESTRUCTURA CON LA INFORMACIÓN DEL NODO
typedef struct 
{
	int Codigo;
	// Otros datos
}Data;

// ESTRUCTURA TIPO NODO SIMPLE
struct Nodo_Simple 
{
	Data Inf;                // Información del nodo
	struct Nodo_Simple *sig; // Siguiente Nodo
};

// NUEVO TIPO DE DATO Nodo_S DEL TIPO NODO_SIMPLE
typedef struct Nodo_Simple   Nodo_S;

// PROTOTIPOS DE RUTINAS

// PROTOTIPO RUTINA: RESERVA MEMORIA PARA UN NODO SIMPLE.  
   Nodo_S    *Crea_Nodo     ( );  
// PROTOTIPO RUTINA: ENTRADA DE DATOS AL NODO.  
   void       Entrada_Datos ( Nodo_S * );
// PROTOTIPO RUTINA: MOSTRAR DATOS DEL NODO.   
   void       Muestra_Datos ( Nodo_S * );  
// PROTOTIPO RUTINA: LIBERAR MEMORIA DEL NODO
   void       Libera_Memoria( Nodo_S * );  
// PROTOTIPO RUTINA: AGREGAR UN NODO AL INICIO DE UNA LISTA SIMPLE 
   Nodo_S    *Add_Start     ( Nodo_S *, Nodo_S * );
// PROTOTIPO RUTINA: VACIAR UNA LISTA SIMPLE
   Nodo_S    *Vaciar_Lista  ( Nodo_S * );
// PROTOTIPO RUTINA: MOSTAR NODOS DE UNA LISTA SIMPLE
   void  	  Mostrar_Lista ( Nodo_S * );
// PROTOTIPO RUTINA: AGREGAR UN NODO AL FINAL DE UNA LISTA SIMPLE 
   Nodo_S    *Add_End       ( Nodo_S *, Nodo_S * );
// PROTOTIPO RUTINA: CONTAR NODOS DE UNA LISTA SIMPLE 
   int 		  Contar_Nodos  ( Nodo_S * );
// PROTOTIPO RUTINA: ELIMINAR UN NODO DE UNA LISTA SIMPLE
   Nodo_S    *Del_Nodo      ( int, Nodo_S * );