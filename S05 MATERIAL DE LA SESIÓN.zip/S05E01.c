// Programa S04E08.c  (Actividad Autónoma)
// Asignatura: Estructura de Datos
// Crear una Lista Simple y Agregar Nodo al	Inicio de la Lista.
// Programa de uso académico
// Realizado por: Eladio Dapena Gonzalez
// Fecha 11/01/2026
/* INCLUSIÓN DE BIBLIOTECAS */
   #include<stdio.h>
   #include<stdlib.h>
// DEFINICIONES, DECLARACIONES, PROTOTIPOS
// DEFINIR NUEVOS TIPOS DE DATOS
   // DEFINICIÓN DEL TIPO DE DATO Data
      typedef struct 
      {
	      int Codigo;
	      // Otros datos
      }Data;
  // DEFINICIÓN DEL TIPO DE DATO  NODO SIMPLE Nodo_S
     typedef struct  
     {
	     Data Inf;           // Información del nodo
	     struct Nodo_S *sig; // Siguiente Nodo
     }Nodo_S;
// PROTOTIPOS DE RUTINAS
// PROTOTIPO RUTINA: RESERVA MEMORIA PARA UN NODO SIMPLE.  
   Nodo_S    *Crea_Nodo();  
// PROTOTIPO RUTINA: ENTRADA DE DATOS AL NODO.  
   unsigned char       Entrada_Datos(Nodo_S *);
// PROTOTIPO RUTINA: MOSTRAR DATOS DEL NODO.   
   unsigned char       Muestra_Nodo(Nodo_S *);  
// PROTOTIPO RUTINA: LIBERAR MEMORIA DEL NODO
   unsigned char       Libera_Memoria_Nodo(Nodo_S *);  
// PROTOTIPO RUTINA: AGREGAR UN NODO  AL INICIO DE LA LISTA 
   Nodo_S              *Add_Start(Nodo_S *, Nodo_S *);
// PROGRAMA PRINCIPAL
int main ()
{
	printf("*** AGREGAR NODO AL INICIO LISTA SIMPLE S04E08.c\n"); 
	// VARIABLE DE REFERENCIA A LA LISTA
 Nodo_S *Ini=NULL;  // Inicialmente vacía
 // VARIABLE Nodo_S  (Nodo Simple)
 Nodo_S *d;
	// RESERVA MEMORIA PARA UN NODO SIMPLE.   
	d = Crea_Nodo();
	if (d == NULL)  // Verificar reserva
 	printf ("\t\t-ERROR EN RESERVA DE MEMORIA\n");
	else
	{
  printf("**** DATOS GUARDADOS  EN Ini REFERENCIA AL INICIO DE LA LISTA ****\n");
  Muestra_Nodo(Ini);
  printf("\t-ENTRADA DE DATOS DE UN NODO SIMPLE d\n");
  Entrada_Datos(d);
	 d->sig=NULL;
  printf("\t-AGREGAR NODO AL INICIO DE  LA LISTA\n");
 		Ini=Add_Start(Ini, d); 
  printf("\t-DATOS GUARDADOS EN Ini INICIO DE LA LISTA\n");
  Muestra_Nodo(Ini);
		printf("\t-DATOS GUARDADOS  EN NODO d\n");
		Muestra_Nodo(d);
 // LIBERAR MEMORIA DEL NODO
		printf("\t-LIBERAR MEMORIA DEL NODO SIMPLE ****\n");
	 if (!Libera_Memoria_Nodo(d))
		{
	 	printf ("\t\t-ERROR EN LIBERAR MEMORIA DEL NODO\n");
		}
	 else
		{
	 	printf("\t\t-MEMORIA DEL NODO LIBERADA CORRECTAMENTE\n");
	 }
		// INICIALIZA VARIABLE PUNTERO A NULL	PARA EVITAR REFERENCIAS INDESEADAS
		Ini=NULL;
		d=NULL;
	}
	return 0;
}
// DECLARACIONES  DE RUTINAS
/*****************************************************
	* Rutina: Crea_Nodo_Simple	Tipo: Apuntador a Nodo_S
	* Parámetros:	 Ninguno
	* Descripción: Reserva memoria para un nodo simple
	* Rutina diseñada para uso académico
	* Realizado por: Dr. Eladio Dapena Gonzalez
	****************************************************/		
Nodo_S	*Crea_Nodo()
{
	Nodo_S *Nodo=NULL;
	Nodo=(Nodo_S *)malloc (sizeof(Nodo_S));
	return(Nodo);
}
/*******************************************************
	* Rutina: Entrada_Datos	Tipo: Función unsigned char
	* Parámetros:	 1.- Tipo Apuntador Nodo_S (Nodo Simple)
	* Descripción: Entrada de datos a un nodo simple
	* Retorna    : 1 si OK, 0 si error
	* Rutina diseñada para uso académico
	* Realizado por: Dr. Eladio Dapena Gonzalez
	******************************************************/
unsigned char Entrada_Datos (Nodo_S *n)
{
	unsigned char R=1;
	if (n == NULL)
		R=0;
	else
	{
	 printf("\t\tIndique CODIGO      : ");
	 scanf("%d",&n->Inf.Codigo);
			 // Entrada de Otros datos 
	}
return(R);
}
/*********************************************************
	* Rutina: Muestra_Nodo	Tipo: Función unsigned char
	* Parámetros:	 1.- Tipo Apuntador Nodo_S (Nodo Simple)
	* Descripción: Muestra datos de un nodo simple
	* Retorna    : 1 si OK, 0 si error
	* Rutina diseñada para uso académico
	* Realizado por: Dr. Eladio Dapena Gonzalez
	********************************************************/
unsigned char Muestra_Nodo (Nodo_S *n)
{
	unsigned char R=1;
	if (n == NULL)
	{
		printf("\t\tNODO VACIO\n");
		R=0;
	}
	else
	{
	 printf("\t\tCODIGO      : %d\n",n->Inf.Codigo);
		printf("\t\tSIGUIENTE   : %p \n",n->sig);
 // Mostrar Otros datos 
	}
return(R);
}
/********************************************************
	* Rutina: Libera_Memoria_Nodo	Tipo: Función unsigned char
	* Parámetros:	 1.- Tipo Apuntador Nodo_S (Nodo Simple)
	* Descripción: Libera memoria de un nodo simple
	* Rutina diseñada para uso académico
	* Realizado por: Dr. Eladio Dapena Gonzalez
	*******************************************************/
unsigned char   Libera_Memoria_Nodo(Nodo_S *n)
{
	unsigned char R=1;
	if (n == NULL)
		R=0;
	else
	free(n);
return(R);
}
/***********************************************************************
 * Rutina: Add_Start		Tipo: Apuntador a Nodo	
 * Parámetros:	1.- Apuntador a un tipo Nodo  (Inicio de la Lista)
 *              2.- Apuntador a el Nodo a agregar
 * Descripción: Agrega al inicio de la lista un nuevo nodo
 * Rutina diseñada para docencia
 * Realizado por: Dr. Eladio dapena Gonzalez
 ***********************************************************************/
Nodo_S *Add_Start(Nodo_S *ini, Nodo_S *N)
{
		if (N!= NULL)
		{
	  printf("\t\t!!!!\n"); //ELIMINAR ESTA LINEA
	  printf("\t\t!!!! DEBE CREAR RUTINA Add_Start \n"); //ELIMINAR ESTA LINEA
	  printf("\t\t!!!!\n"); //ELIMINAR ESTA LINEA
			// ESCRIBA SU CÓDIGO AQUI
		}
return ini; //Verificar sus datos de retornar
}
