// Programa: Prueba_Lista.c
// Asignatura: Estructura de Datos
// Actividad práctica AUTÓNOMA sesión 05
// Menú con opciones para operaciones con Listas Simples
// Programa de uso académico
// Realizado por: Eladio Dapena Gonzalez
// Fecha 01/02/2026
/* INCLUSIÓN DE BIBLIOTECAS */

/* INCLUSIÓN DE BIBLIOTECAS */
   #include <stdio.h>
   #include <stdlib.h>
   #include "Lista_Simple.h"

// PROTOTIPOS DE RUTINAS PROPIAS
   void    Muestra_Opciones( );
   int     Menu            ( int, int );
   Nodo_S *Hacer           ( int, Nodo_S *, Nodo_S * );

// PROGRAMA PRINCIPAL
int main ()
{
// DECLARACION DE VARIABLES
 Nodo_S *d, *Ini;
 int op;            // Opción de menú
 Ini=NULL;d=NULL;  // Inicio de la lista (Vacía)
	// MOSTRAR MENU Y EJECUTAR ACCIONES
  do
  {
  	op=Menu(1,7);  						// Muestra Menú y pide opción
			if (op!=7)
			{
  	Ini=Hacer(op,Ini,d); // Ejecuta acción seleccionada
  	printf("\tPresione una tecla para continuar...");
   fflush(stdin);
  	getchar();
			}
	 }while (op!=7);
 Ini=Vaciar_Lista(Ini);
 return 0;
 }

// DECLARACIONES DE RUTINAS

/*******************************************************************
 * Rutina      : Muestra_Opciones		Tipo: Procedimiento	
 * Parámetros  :	NO
	* Retorna     : NO
 * Descripción : Muestra un menu de opciones
 * Autor       : Dr. Eladio Dapena Gonzalez
	* Uso         : Académico
 *******************************************************************/
void Muestra_Opciones()
{
 printf("\033[2J"); // Limpia terminal códigos de escape (ANSI X3.64) 
	printf("\t***************  GESTION DE UNA LISTA   ***************\n");
	printf("\t*\t                                                   *\n");
	printf("\t*\t Agregar Nodo al Inicio .................   1      *\n");
	printf("\t*\t Agregar Nodo al Final  .................   2      *\n");
	printf("\t*\t Contar Nodos           .................   3      *\n");
	printf("\t*\t Mostrar Lista          .................   4      *\n");
 printf("\t*\t Eliminar Nodo          .................   5      *\n");
 printf("\t*\t Vaciar Lista           .................   6      *\n");
	printf("\t*\t Finalizar              .................   7      *\n");
	printf("\t*\t                                                   *\n");
	printf("\t*******************************************************\n");
}

/*******************************************************************
 * Rutina      : Menu		Tipo: Entero	
 * Parámetros  :	1.- Límite inferior de las opciones
	*               2.- Límite superior de las opciones
	* Retorna     : Opción seleccionada
 * Descripción : Solicita y valida una opción al usuario
 * Autor       : Dr. Eladio Dapena Gonzalez
	* Uso         : Académico
 *******************************************************************/
int Menu(int n1, int n2)
{
 int o;
 int resultado;
do 
{
 Muestra_Opciones();
 printf("\t\t\tINDIQUE UNA OPCION : ");
 resultado = scanf("%d", &o);
 while (getchar() != '\n');
  if (resultado != 1) 
		{
   printf("\t\t\tERROR: Debe ingresar un numero valido.\n");
			o = n1 - 1;  // Forzar que continúe el ciclo
  }
  else 
		if (o < n1 || o > n2) 
		{
   printf("\t\t\tERROR: OPCION FUERA DE RANGO [%d-%d].\n", n1, n2);
		}
 } while (resultado != 1 || o < n1 || o > n2);
 return o;
}

/***********************************************************************
 * Rutina      : Hacer		Tipo: Apuntador a Nodo retorna un puntero a nodo
 * Parámetros  :	1.- Entero o  Acción a ejecutar
 *							        2.- Nodo  Puntero a un dato tipo Nodo (inicio de lista)
 *							        3.- Nodo  Puntero a un dato tipo Nodo
	* Retorna     : Puntero a el Nodo Simple. (Nodo_S)	
 * Descripción : Ejecuta la acción seleccionada por el usuario
 * Autor       : Dr. Eladio Dapena Gonzalez
	* Uso         : Académico
 ***********************************************************************/
Nodo_S *Hacer(int o, Nodo_S *Ini, Nodo_S * Ele)
{
	int c,ne;
	switch (o)
	{
	 case 1:  // Opción 1 del menu Agregar nodo al final
		Ele=Crea_Nodo();
		if (Ele!=NULL)
		{
			Entrada_Datos(Ele);
			Ini=Add_Start(Ini,Ele);
		}
		else
 	 printf ("\t\t-ERROR EN RESERVA DE MEMORIA\n");
		break;
		case 2: // Opción 1 del menu Agregar nodo al final
			Ele=Crea_Nodo();
			if (Ele!=NULL)
			{
				Entrada_Datos(Ele);
				Ini=Add_End(Ini,Ele);
			}
			else
		 	printf ("\t\t-ERROR EN RESERVA DE MEMORIA\n");
			break;
		case 3:
			printf("\tTOTAL NODOS EN LA LISTA = %d\n",Contar_Nodos(Ini));
			break;
		case 4:
		 if (Ini!=NULL)
			{
			 printf("\tNODOS EN LA LISTA:   \n"); 
			 Mostrar_Lista(Ini);
			}
			else
			  printf("\t LISTA VACIA\n");
			break;
		case 5:
            c=Contar_Nodos(Ini);
			if (c>0)
			 {
			  printf("Indique nodo a eliminar [1,%d] : ",c);scanf("%d",&ne);
			  if (ne>0 && ne<=c)
			   Ini=Del_Nodo(ne,Ini);
			  else
			   printf("No se puede Eliminar nodo no existe\n");
			 }
			 else
			  printf("NO se puede eliminar Lista vacia \n");
			break;
		case 6:
			Ini=Vaciar_Lista(Ini);
			break;
	}
	return Ini;
}
