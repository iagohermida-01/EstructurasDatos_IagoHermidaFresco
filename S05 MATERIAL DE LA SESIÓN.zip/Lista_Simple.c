// BIBLIOTECA Lista_Simple. 
// FICHERO DE DECLARACIONES DE RUTINAS
// ESTRUCTURA DE DATOS
// Descripción : Rutinas de gestión de una Lista Simple
// Autor       : Dr. Eladio Dapena Gonzalez
// Uso         : Académico
// Fecha       : 02/01/2024

/* INCLUSIÓN DE BIBLIOTECAS */
#include <stdio.h>
#include <stdlib.h>
#include "Lista_Simple.h"

// DECLARACIONES DE RUTINAS

/*******************************************************************
 * Rutina      : Crea_Nodo		Tipo: Apuntador a Nodo	
 * Parámetros  :	NO
 * Retorna     : Puntero al nodo creado
 * Descripción : Asigna memoria dinámica para un nuevo nodo
 * Autor       : Dr. Eladio Dapena Gonzalez
 * Uso         : Académico
 *******************************************************************/
Nodo_S *Crea_Nodo()
{
 return (Nodo_S *)calloc(1,sizeof(Nodo_S));
}			


/*******************************************************************
 * Rutina      : Entrada_Datos		Tipo: Procedimiento
 * Parámetros  :	1.- Dirección del nodo a actualizar
	* Retorna     : NO
 * Descripción : Solicita datos del nodo
 * Autor       : Dr. Eladio Dapena Gonzalez
 * Uso         : Académico
 * Fecha       : 02/01/2024
 *******************************************************************/
void   Entrada_Datos(Nodo_S *a)
{
  int codigo;
		printf("\t\tINDIQUE UN CODIGO : ");
		scanf("%d",&codigo); 
 a->Inf.Codigo=codigo; 
		a->sig=NULL;
}
/*******************************************************************
 * Rutina      : Muestra_Datos		Tipo: Procedimiento
 * Parámetros  :	1.- Dirección del nodo a mostrar
 * Retorna     : NO
 * Descripción : Muestra lo datos de un nodo
 * Autor       : Dr. Eladio Dapena Gonzalez
 * Uso         : Académico
 *******************************************************************/
void   Muestra_Datos(Nodo_S *a)
{
  if (a!=NULL)
  {
		printf("\tCODIGO    : %d  \n",a->Inf.Codigo);	
		printf("\tSiguiente : %p\n",a->sig);
  }
  else
  		printf("\tNODO VACIO\n");
}
/*******************************************************************
 * Rutina      : Libera_Memoria		Tipo: Procedimiento
 * Parámetros  :	1.- Dirección del nodo a liberar memoria
 * Retorna     : NO
 * Descripción : Libera la memoria ocupada `por un nodo
 * Autor       : Dr. Eladio Dapena Gonzalez
 * Uso         : Académico
 *******************************************************************/
void   Libera_Memoria(Nodo_S *a)
{
	 free(a);
}
/*******************************************************************
 * Rutina      : Add_Start		Tipo: Apuntador a Nodo	
 * Parámetros  : 1.- Puntero a un tipo Nodo  (Inicio de la Lista)
 *               2.- Puntero a el Nodo a agregar
 * Retorna     : Puntero a el Nodo Simple. (Nodo_S)
 * Descripción : Agrega al INICIO de la lista un nuevo nodo
 * Autor       : Dr. Eladio Dapena Gonzalez
 * Uso         : Académico
 *******************************************************************/
Nodo_S *Add_Start(Nodo_S *Inicio, Nodo_S *N)
{

	// CONSTRUYA LA RUTINA	PARA AGREGAR UN NODO AL INICIO DE LA LISTA
 printf("\t\t-CONSTRUIR SU RUTINA AGREGAR NODO AL INICIO DE LA LISTA\n");

 return Inicio; // MODIFIQUE SEGÚN SU CÓDIGO
}
 
/*******************************************************************
 * Rutina       : Vaciar_Lista		Tipo: Apuntador a Nodo	
 * Parámetros   :	1.- Apuntador a un tipo Nodo  (Inicio de la Lista)
 * Retorna      : Puntero valor NULL
 * Descripción  : Libera la memoria utilizada por los nodos de la lista
 * Autor        : Dr. Eladio Dapena Gonzalez
 * Uso          : Académico
 *******************************************************************/
Nodo_S *Vaciar_Lista(Nodo_S *Inicio)
{

	// CONSTRUYA LA RUTINA	PARA AGREGAR UN NODO AL INICIO DE LA LISTA
 printf("\t\t-CONSTRUIR SU RUTINA VACIAR LA LISTA\n");

 return NULL; //	MODIFIQUE SEGÚN SU CÓDIGO
}

/*******************************************************************
 * Rutina       : Mostrar_Lista		Tipo: Procedimiento	
 * Parámetros   :	1.- Apuntador a un tipo Nodo  (Inicio de la Lista)
 * Retorna      : NO
 * Descripción  : Muestra el código de cada nodo. 
 * Autor        : Dr. Eladio Dapena Gonzalez
 * Uso          : Académico
 ******************************************************************/
void  Mostrar_Lista(Nodo_S *a)
{

	// CONSTRUYA LA RUTINA	PARA AGREGAR UN NODO AL INICIO DE LA LISTA
 printf("\t\t-CONSTRUIR SU RUTINA MOSTRAR LA LISTA\n");

}

/***********************************************************************
 * Rutina      : Add_End		Tipo: Apuntador a Nodo	
 * Parámetros  :	1.- Apuntador a un tipo Nodo  (Inicio de la Lista)
 *               2.- Apuntador a el Nodo a agregar
 * Retorna     : Puntero a el Nodo Simple. (Nodo_S)
 * Descripción : Agrega al final de la lista un nuevo nodo
 * Autor       : Dr. Eladio Dapena Gonzalez
 * Uso         : Académico
 ***********************************************************************/
Nodo_S *Add_End(Nodo_S *Inicio, Nodo_S *N)
{

	// CONSTRUYA LA RUTINA	PARA AGREGAR UN NODO AL FINAL DE LA LISTA
 printf("\t\t-CONSTRUIR SU RUTINA AGREGAR NODO AL FINAL DE LA LISTA\n");

 return Inicio;//	MODIFIQUE SEGÚN SU CÓDIGO
}

/*******************************************************************
 * Rutina      : Contar nodos		Tipo: Entero	
 * Parámetros  :	1.- Apuntador a un tipo Nodo  (Inicio de la Lista)
 * Retorna     : Cantidad de Nodos
 * Descripción : Contar la cantidad de nodos en la lista
 * Retorna     : Cantidad de nodos
 * Autor       : Dr. Eladio Dapena Gonzalez
 * Uso         : Académico
 ***********************************************************************/
int Contar_Nodos(Nodo_S *Inicio)
{

	// CONSTRUYA LA RUTINA	PARA CONTAR NODOS DE LA LISTA
 printf("\t\t-CONSTRUIR SU RUTINA CONTAR NODOS DE LA LISTA\n");

 return 0;  //	MODIFIQUE SEGÚN SU CÓDIGO
}

/***********************************************************************
 * Rutina      : Del_Nodo		Tipo: Apuntador a Nodo
 * Parámetros  : 1.- Nodo a eliminar
 *               2.- Apuntador a un tipo Nodo  (Inicio de la Lista)
 * Retorna     : Puntero a el Nodo Simple. (Nodo_S)	
 * Descripción : Elimina un nodo de la lista
 * Autor       : Dr. Eladio Dapena Gonzalez
 * Uso         : Académico
 ***********************************************************************/
Nodo_S *Del_Nodo(int n, Nodo_S *Inicio)
{

	// CONSTRUYA LA RUTINA	PARA ELIMINAR UN NODO DE LA LISTA
 printf("\t\t-CONSTRUIR SU RUTINA ELIMINAR NODO DE LA LISTA\n");

return Inicio;//	MODIFIQUE SEGÚN SU CÓDIGO
}