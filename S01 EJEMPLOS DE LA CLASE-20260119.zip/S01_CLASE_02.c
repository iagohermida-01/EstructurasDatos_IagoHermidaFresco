// Programa S01_CLASE_02
// Secuencias Asignación y salida printf()
// Autor  : Eladio Dapena Gonzalez
// Fecha  : XX/XX/XXXX
// Programa de uso académico
// Inclusión de Bibliotecas comunes
#include <stdio.h>
#include<string.h>
// Definición de de nuevos tipos de datos
typedef     int	        Edad;
// Definiciones del tipo registro
typedef struct 
{
 float x;
 float y;
}Punto2D;
typedef  struct
{
 int    h, m, s;
} Hora;	
// Definición de constantes
#define 		PI   3.14159
const	float	G  = 9.8;	
	
/* ***********************
 * Función principal     * 	
 ************************/
int main(void)
{
// Constantes de ámbito local
   #define   	    NP  1000
   const	int	    NT = 1000;
//Declaraciones de variables de ámbito local
float   a;
int     i;
char    C;
	
// Arreglo unidimensional Inicialización en la declaración
    int   I[5]  = {12, 25, 35, 15, 1};
    int   J[3]  = {0};
    int   K[3]  =  { 1 };
    int   T[4];   T[0] = T[1] = T[2] = T[3]=0;
// Cadenas
    char    Lugar[9];
// Arreglo bidimensional inicialización en la declaración
    int     BEdad1[4][4] =  {{12,25,35,10}, {12,24,36,43},{15,10,54,16},{10,20,31,40}};
    Punto2D P1;
    Hora    HE;
// Asignación variables escalares
a   = 12.5;
i   = 10;
C   = 'A';
//Asignación Cadena
//Lugar = "Galicia";  // sustituir por linea siguiente
strcpy(Lugar,"Galicia");
// Estructuras Punto2D y Hora
P1.x=3.5;P1.y=4.2; 
HE.h=10;HE.m=15;HE.s=30;

printf("***** SALIDA DE DATOS *****\n");
// Escribir constantes
printf("\tConstantes\n");
printf("\t\t PI: %4.5f\t G: %4.2f\t NP: %d\t NT: %d\n",PI,G,NP,NT);
// Escribir variables escalares
printf("\tVariables\n");
printf("\t\tA = %4.2f  I= %d  c= %c\n",a,i,C);
// Escribir arreglos unidimensionales
printf("\tVectores\n");
printf("\t\tI [%d,%d,%d,%d,%d]\n",I[0],I[1],I[2],I[3],I[4]);
printf("\t\tJ [%d,%d,%d]\n",J[0],J[1],J[2]);
printf("\t\tK [%d,%d,%d]\n",K[0],K[1],K[2]);
printf("\t\tT [%d,%d,%d,%d]\n",T[0],T[1],T[2],T[3]);
printf("\tCadenas\n");
printf("\t\tLugar = %s\n",Lugar);
printf("\t Matriz BEdad1\n");
printf("\t\t|%d,%d,%d,%d|\n",BEdad1[0][0],BEdad1[0][1],BEdad1[0][2],BEdad1[0][3]);
printf("\t\t|%d,%d,%d,%d|\n",BEdad1[1][0],BEdad1[1][1],BEdad1[1][2],BEdad1[1][3]);
printf("\t\t|%d,%d,%d,%d|\n",BEdad1[2][0],BEdad1[2][1],BEdad1[2][2],BEdad1[2][3]);
printf("\t\t|%d,%d,%d,%d|\n",BEdad1[3][0],BEdad1[3][1],BEdad1[3][2],BEdad1[3][3]);
printf("\tRegistros\n");
printf("\t\tPunto2D\t P1[%2.1f,%2.1f]\n",P1.x,P1.y);
printf("\t\tHora\t HE[%d,%d,%d]\n",HE.h,HE.m,HE.s);
return 0;
}
