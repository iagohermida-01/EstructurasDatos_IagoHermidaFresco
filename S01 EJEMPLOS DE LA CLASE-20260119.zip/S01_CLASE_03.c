// Programa S01_CLASE_03
// Secuencias. Entrada Uso scanf()
// Autor  : Eladio Dapena Gonzalez
// Fecha  : XX/XX/XXXX
// Programa de uso académico
// Inclusión de Bibliotecas comunes
#include <stdio.h>
	
/* ***********************
 * Función principal     * 	
 ************************/
int main()
{
 float Base,Altura,area; 				
 printf("*****  AREA DE UN TRIANGULO  *****\n");
 printf("\t--ENTRADA DE DATOS\n");
 printf("\t\tINDIQUE LA BASE    : ");
 scanf("%f",&Base);	
 printf("\t\tINDIQUE LA ALTURA  : ");
 scanf("%f",&Altura);		
 area = Base * Altura /2 ;
 printf("\t--RESULTADOS\n");
 printf("\t\tAREA  = %4.2f\n",area);
return 0;
}
