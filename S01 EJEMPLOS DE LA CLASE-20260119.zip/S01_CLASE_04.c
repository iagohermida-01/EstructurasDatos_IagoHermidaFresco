// Programa S01_CLASE_04
// Ámbito de las variables
// Autor  : Eladio Dapena Gonzalez
// Fecha  : XX/XX/XXXX
// Programa de uso académico
// Inclusión de Bibliotecas comunes
#include <stdio.h>
float Base=10;	
	
/* ***********************
 * Función principal     * 	
 ************************/		
int main()
   {
     float altura = 20; 				
     {
        float area;			
        area = Base * altura;
        printf("Area = %4.2f\n",area);
     }
     area = 2 * area;		
return 0;
}
