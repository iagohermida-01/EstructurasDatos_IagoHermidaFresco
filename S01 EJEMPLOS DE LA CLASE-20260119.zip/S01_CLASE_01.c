// Programa S01_CLASE_01
// Normas 1-2-3 Definiciones y Declaraciones (Resumen)
// Autor  : Eladio Dapena Gonzalez
// Fecha  : XX/XX/XXXX
// Programa de uso académico
// Inclusión de Bibliotecas comunes
#include <stdio.h>
#include <string.h>
// Definiciónde de nuevos tipos de datos
typedef     int	     Edad;
typedef     double   Salarios[10];				
typedef     float    Kilos[30];
// Definición tipo registro
struct Punto2D
{
 float x;
 float y;
};
// Definición tipo registro con typedef	
typedef  struct
{
  int	 h, m, s;
} Hora;
// Definiciones de Constantes Globales
#define   		NP   1000
const	float	  pi = 3.14159;
// Declaración de variables Globales
float		x1, z, SN;
struct Punto2D		p, P1, P2, P3;

/* ***********************
 * Función principal     * 	
 ************************/
int main(void)
{
// Constantes de ámbito local
   const	int	  NT = 1000;
//Declaraciones de variables escalares de ámbito local
float		Temperatura;
double	Velocidad;
int		  i, j;
long    Piezas; 
char 		Letra, letra;
// Variables compuestas Vectores de ámbito local
int      N[10];
float    Distancias[100];
// Variables compuestas Cadenas
char     DNI[10];
char     Dia[6]   = "Lunes";
char     Lugar[9] = "Galicia";
// Variables compuestas Matrices
int      BEdad[4][4];
float    BPesos[35][2];
char     BLetras[10][10]; 
// Variables asociadas a los nuevos tipos y estructuras
Edad	   a, E[10];
Salarios s, S[7];
Kilos    p, P[5];
struct   Punto2D P1,P2;
Hora     HE,HF,H[10];
return 0;
}
